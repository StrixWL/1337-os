Skin # 27 | June 30th, 2003
Title : Bon App�tit 
Theme : Chi from Chobits (manga)

Please ask permission to put this skin on your site. I just like to keep a tab on where the skins I do go. Any other questions or comments just email me. ^_^

-Van
Email: telekineticprodigy@yahoo.com
AIM : AsatoTsuzuki
http://www.geocities.com/telekineticprodigy